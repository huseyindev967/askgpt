
import 'package:flutter/material.dart';

void main() => runApp(AskGPTApp());

class AskGPTApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AşkGPT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.pink,
      ),
      home: AskGPTScreen(),
    );
  }
}

class AskGPTScreen extends StatefulWidget {
  @override
  _AskGPTScreenState createState() => _AskGPTScreenState();
}

class _AskGPTScreenState extends State<AskGPTScreen> {
  final List<Map<String, String>> messages = [];
  final TextEditingController _controller = TextEditingController();

  void sendMessage(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      messages.add({'user': text});
      messages.add({'bot': generateResponse(text)});
    });
    _controller.clear();
  }

  String generateResponse(String input) {
    final responses = [
      "Canım, seni düşünmek bile yüzümde gülümseme bırakıyor. 💖",
      "Bu mesajın kalbime dokundu... Sen hep böyle tatlı mısın? 😍",
      "Seninle konuşmak, günün en güzel anı! 💌",
      "Yıldızlar bile senin kadar parlamıyor bu gece... 🌟",
    ];
    return responses[input.length % responses.length];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('AşkGPT 💘'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12.0),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                final isUser = message.containsKey('user');
                return Align(
                  alignment: isUser
                      ? Alignment.centerRight
                      : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 6.0),
                    padding: const EdgeInsets.all(12.0),
                    decoration: BoxDecoration(
                      color: isUser ? Colors.pink[100] : Colors.grey[200],
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    child: Text(
                      message.values.first,
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ),
                );
              },
            ),
          ),
          Divider(height: 1.0),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration.collapsed(
                      hintText: 'Bir şeyler yaz... ❤️',
                    ),
                    onSubmitted: sendMessage,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  onPressed: () => sendMessage(_controller.text),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
